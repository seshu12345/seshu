
  ##this is an <h2> tag
  ###this is an <h3> tag
  #*this text will be italic*
  #-this will also be italic-
  #**this text will be bold**
  #--this will also be bold--
  #*you **can** combine them*
  #*item 1
  #*item 2
  # *ityem 2a
  # *item 2b
  
  
  ![rohit](https://resources.platform.bcci.tv/bcci/photo/2019/12/18/f8838142-87b1-4db1-895d-92ecf54c4dcd/VRP4805.jpg)
